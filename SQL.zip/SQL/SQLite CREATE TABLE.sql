CREATE TABLE Movie (MovId int PRIMARY KEY NOT NULL, MovTitle varchar(50) NOT NULL, 
                    MovYear int NOT NULL, MovTime int NOT NULL, MovLang varchar(25) NOT NULL, 
                    MovDateRel varchar NOT NULL, Country varchar(10) NOT NULL)