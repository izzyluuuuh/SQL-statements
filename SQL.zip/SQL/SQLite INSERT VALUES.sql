INSERT INTO Movie (movid, movtitle, movyear, movtime, movlang, movdaterel, country)
VALUES 
(101, 'Titanic', 1997, 145, 'English', '1997-02-02', 'US'),
(102, 'Home Alone', 1990, 160, 'English', '1990-05-16', 'UK'),
(103, 'The Matrix', 1999, 123, 'English', '1999-08-16', 'UK'),
(104, 'Spiderman', 2002, 128, 'English', '2002-05-30', 'US'),
(105, 'Batang X', 1995, 136, 'Tagalog', '1995-03-21', 'PH'),
(106, 'Your Name', 2016, 109, 'English', '2016-11-11', 'JP'),
(107, 'Toy Story', 1995, 115, 'English', '1995-12-24', 'US');